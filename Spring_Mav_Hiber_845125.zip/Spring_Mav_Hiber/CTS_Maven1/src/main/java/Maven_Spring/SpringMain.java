package Maven_Spring;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class SpringMain {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		ApplicationContext beanFactory=new ClassPathXmlApplicationContext("Maven_Spring.xml");
		FirstBean myBean=(FirstBean)beanFactory.getBean("Bean1");
		myBean.display();
			
	}
}


