package Maven_Spring;


	public class FirstBean {
		String name;
		public void setName(String name){
			this.name=name;
		}
		public void display()
		{System.out.println("welcome spring by:"+name);}

	}


