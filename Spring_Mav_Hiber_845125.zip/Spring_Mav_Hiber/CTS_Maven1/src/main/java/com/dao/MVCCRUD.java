package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.EmployeeBean;

public class MVCCRUD {
@Autowired
EmpJDBCController dao2;
@RequestMapping(value="/save",method=RequestMethod.POST)
public String save(EmployeeBean emp){
dao2.save1(emp);
return"redirect:/viewemps";
}
@RequestMapping("/viewmps")
public String viewmaps(Model m){
List<EmployeeBean>list=dao2.getEmployees();
m.addAttribute("emplist",list);
return"viewmaps";
}
}
