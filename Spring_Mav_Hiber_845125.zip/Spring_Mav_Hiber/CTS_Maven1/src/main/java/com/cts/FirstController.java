package com.cts;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class FirstController {
     //similar to @webservlet
     @RequestMapping("/hdfclogin")
     public String display1()
     {
    	 //connecting to view layer
    	 return "callview";//jsp view file name
     }
     //send data from controller to view
     @RequestMapping("/signin")
     //a model is a map object that is used to store attr value pairs
     public String display2(Model m)
     {
    	 m.addAttribute("myname","Divya");
    	 return "view12";
    	 
     }
     
}
