package com.cts;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FormController {
@RequestMapping(value="/checkaccount",method=RequestMethod.POST)
//@requestparam--receive value from jsp
public String display(@RequestParam("user1") String username,@RequestParam("pass") String pass1,Model m)
{
	if(username.equals("Divya"))
			{
		String msg="Hello"+username;
		//add a message to model
		m.addAttribute("message",msg);
		return "successpage";//viewjsp
			}
	else{
		String msg="Sorry!!!"+username;
		m.addAttribute("message1",msg);
		return "errorpage";//view jsp
	}
		
}
}
