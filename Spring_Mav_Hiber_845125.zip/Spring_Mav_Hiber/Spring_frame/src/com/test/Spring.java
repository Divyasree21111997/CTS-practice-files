package com.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import org.springframework.context.support.AbstractApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.Employee_JdbcTemplate1;

public class Spring {
public static void main(String...args){
ApplicationContext beanFactory=new ClassPathXmlApplicationContext("SpringConfig.xml");
FirstBean myBean=(FirstBean)beanFactory.getBean("Bean1");
myBean.display();
AbstractApplicationContext context=new AnnotationConfigApplicationContext(AnnoBean1.class);
AnnoBean myBean1=(AnnoBean)
context.getBean("SpringAnnoBean");
myBean1.disp("yash");
EmployeeBean myBean2=(EmployeeBean)beanFactory.getBean("myemployee1");
myBean2.show();

Student_Course sc1=(Student_Course)beanFactory.getBean("course1");
	System.out.println(sc1.getSid());
	System.out.println(sc1.getName());
	System.out.println(sc1.getCid());
	System.out.println(sc1.getCname());
	
	
	User_Properties myBean11=(User_Properties)beanFactory.getBean("prop1");//bean object
	System.out.println(myBean11.getUser()+" "+myBean11.getRole()+" "+myBean11.getEmail());
	
	System.out.println("REFTAG(WITHOUT AUTOWIRE)");
	Bank myBean4=(Bank)beanFactory.getBean("bank_aw");//bean object
	System.out.println(myBean4.getBankname());
	System.out.println(myBean4.getMgrname());
	System.out.println(myBean4.getB1().getCity());
	System.out.println(myBean4.getB1().getState());
	
	System.out.println("AUTOWIRE (WITHOUT REFTAG):");
	Bank myBean5=(Bank)beanFactory.getBean("bank_aw1");//bean object
	System.out.println(myBean5.getBankname());
	System.out.println(myBean5.getMgrname());
	System.out.println(myBean5.getB1().getCity());
	System.out.println(myBean5.getB1().getState());
	
	
	
	System.out.println("AUTOWIRE(CONSTRUCTOR):");
	EmployeeBean myBean3=(EmployeeBean)beanFactory.getBean("myemployee2");
	myBean3.show();
	
	
	System.out.println("AUTOWIRE ANNOTATION:");

	 Bank_AutoWire myBean31=(Bank_AutoWire) beanFactory.getBean("anno1"); //bean object

	 System.out.println(myBean31.getBankname());
	 System.out.println(myBean31.getMgrname());
	 System.out.println(myBean31.getB20().getCity());
	 System.out.println(myBean31.getB20().getState());
	 
	 System.out.println("Collection-setter injection:");

	 Vendor_Collection q=(Vendor_Collection)beanFactory.getBean("ob1");

	 q.displayInfo1();



	 System.out.println("COLLECTION-Dependent object injection");

	 Training_Collection q1=(Training_Collection)beanFactory.getBean("tco1");

	 q1.displayInfo1();
	 
	 System.out.println("Map Collection-Setter Injection::");
	 Assessment_MapCollection q12=(Assessment_MapCollection)beanFactory.getBean("asmap1");
	 q12.display();
	 
	 
	 System.out.println("Collection-constructor Injection");
	 Vendor_coll q3=(Vendor_coll)beanFactory.getBean("ob11");
	 q3.displayinfo();
	 
	 Employee_JdbcTemplate1 s=(Employee_JdbcTemplate1)beanFactory.getBean("mydatabase");
	 System.out.println("SPRING+JDBC:::");
	 List<Employee_Jdbc>e1=s.listemp();
	 System.out.println("ENO NAME SALARY");
	 for(Employee_Jdbc rec:e1)
	 {
	 System.out.println(rec.getEmp_no()+" ");
	 System.out.println(rec.getEmp_name()+" ");
	 System.out.println(rec.getSalary());
	 }
	 ApplicationContext obj = new ClassPathXmlApplicationContext("SpringConfig.xml");

	 SpringAnno_Component myBean6 = (SpringAnno_Component)obj.getBean("SpringAnno_Component");

	 System.out.println(myBean6.training+" "+myBean6.loc);
	 

}
}

