package com.test;

public class Bank {
	String bankname;
	String mgrname;
	Branch b1;
	public String getBankname() {
		return bankname;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	public String getMgrname() {
		return mgrname;
	}
	public void setMgrname(String mgrname) {
		this.mgrname = mgrname;
	}
	public Branch getB1() {
		return b1;
	}
	public void setB1(Branch b1) {
		this.b1 = b1;
	}
}
