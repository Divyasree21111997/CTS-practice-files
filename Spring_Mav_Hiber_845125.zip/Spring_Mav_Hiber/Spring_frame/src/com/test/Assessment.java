package com.test;

public class Assessment {

}
