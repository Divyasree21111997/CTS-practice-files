package com.dao;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import com.test.Employee_Jdbc;
import java.util.List;

public class Employee_JdbcTemplate1 {
	DataSource datasource;
	JdbcTemplate jdbctemplate;
	public void setDatasource(DataSource datasource) {
		this.datasource = datasource;
		jdbctemplate=new JdbcTemplate();
	}
	public List<Employee_Jdbc>listemp()
	{
		String SQL="select *from emp";
		List<Employee_Jdbc>emps=jdbctemplate.query(SQL,new EmployeeMapper());
		return emps;
		
	}
	
	

}
