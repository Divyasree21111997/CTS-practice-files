package com.dao;



import java.util.HashSet;

import java.util.Set;



import org.hibernate.Session;

import org.hibernate.SessionFactory;

import org.hibernate.Transaction;

import org.hibernate.cfg.Configuration;



import com.pojo.CustomerPojo;

import com.pojo.Emp_Pojo;

import com.pojo.VendorPojo;



public class OneToManyRelation {



 public static void main(String[] args) {

 Session s=new Configuration().configure("cts_hibernate.cfg.xml").buildSessionFactory().openSession();

  Transaction t=s.beginTransaction();

  VendorPojo v =new VendorPojo();

  v.setVid1(10);

  v.setVname1("ZOHO");

  v.setEmail("admin@zoho.com");



  CustomerPojo c1=new CustomerPojo();

  c1.setCustid(66);

  c1.setCustname("divya");



  CustomerPojo c2=new CustomerPojo();

  c2.setCustid(65);

  c2.setCustname("sree");



  Set s1=new HashSet();

  s1.add(c1);

  s1.add(c2);

  v.setCust1(s1);// one vendor to many customers

  s.save(v);//==s.persist()

  t.commit();

  s.close();//detached

  System.out.println("One to Many Done...!!!");





 }



}

