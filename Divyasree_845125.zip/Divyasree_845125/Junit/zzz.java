
public class zzz {

	public zzz() {
		super();
	}

}