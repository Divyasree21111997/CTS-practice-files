
public class CalcTestStubs {

}
