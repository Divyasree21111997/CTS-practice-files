
public class Calculate {

	public int sum(int var1, int var2) {
		// TODO Auto-generated method stub
		return var1+var2;
	}

}
