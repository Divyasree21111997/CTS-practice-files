import java.util.Arrays;
import java.util.Collection;

import org.junit.runners.Parameterized.Parameters;

public interface yyy {

	Collection<Object[]> add12();

	protected int expected;

}