import static org.junit.Assert.*;

import org.junit.Test;

public class StudentTest {
Student s1=new Student();

 @Test

 public void test() {
	 s1.setId(1001);
s1.setName("Divya");
 assertEquals(1001,s1.getId());
 assertEquals("Divya",s1.getName());

 }



}

