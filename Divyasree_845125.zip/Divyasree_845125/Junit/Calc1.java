public class Calc1 {
	public int taxcal(int a)
	{
		int sum=a*a;
		return sum;
	}

}
