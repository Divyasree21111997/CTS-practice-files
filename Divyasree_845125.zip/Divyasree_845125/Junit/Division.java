
public class Division {
	int num1,num2;

	public Division(int num1, int num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
	}

	public int division()
	{
		return num1/num2;
	}

}