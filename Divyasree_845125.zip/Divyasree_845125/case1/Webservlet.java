package com.case1;

public @interface Webservlet {

	String value();

}
