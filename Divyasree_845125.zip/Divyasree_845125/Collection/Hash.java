import java.util.Collection;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;
public class Hash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String,Double> hm=new HashMap<String,Double>();
		hm.put("Ram", 10000.0);
		hm.put("Arun", 35000.0);
		hm.put("Ramesh", 45000.0);
		hm.put("Ram", 25000.0);
		hm.put("Arun", 35000.0);
		System.out.println(hm);
		Set<String> s=hm.keySet();
		for(String key:s)
		{
			System.out.println(key);
		}
		Collection<Double> values=hm.values();
		for(Double val:values)
		{
			System.out.println(val);
		}
		Set<Entry<String, Double>> setOfEntries=hm.entrySet();
		for(Entry<String, Double> e:setOfEntries){
			System.out.println(e.getKey()+" = "+e.getValue());
			
		}
	}

}
