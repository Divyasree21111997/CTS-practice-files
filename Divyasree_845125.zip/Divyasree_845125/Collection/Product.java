import java.util.Date;
public class Product {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int id;
		String productName;
		Double price;
		Date dateOfManufacture;
	}
	int id;
	private String productName;
	private Double price;
	private Date dateOfManufacture;		
	public Product(int id,String productName,Double price,Date dateOfManufacture ){
			this.id=id;
			this.productName=productName;
			this.price=price;
			this.dateOfManufacture=dateOfManufacture;
		}
		public String toString(){
			return "product["+id+" "+productName+" "+price+" "+dateOfManufacture+"]";
		}

	}


