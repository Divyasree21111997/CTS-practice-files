import java.util.Comparator;

public class Idcomparator implements Comparator<Product> {
	public int compare(Product o1,Product o2)
	{
		int result=0;
		if(o1.id<o2.id)
			result=-1;
		else if(o1.id>o2.id)
			result=+1;
		else
			return 0;
		return result;
	}

	//@Override
	

}
